package quickstart.Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import functionLibrary.BaseMethods;

public class LandingPage {
	
	WebDriver driver;
	BaseMethods baseMethods;
	
	public LandingPage(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver, this);
		baseMethods = new BaseMethods();
	}
	
	@FindBy(xpath = "//button[text()='Login']")
	private WebElement btn_Login;
	
	@FindBy(xpath = "//input[@name='username']")
	private WebElement inputTextBox_username;
	
	@FindBy(xpath = "//input[@name='password']")
	private WebElement inputTextBox_Password;
	
	@FindBy(xpath = "//div[@class='d-flex justify-content-between']")
	private WebElement Text_Welcome;
	
	public boolean loginBtnVisible() {
		String buttonName = btn_Login.getText();
		System.out.println(buttonName);
		if (buttonName.contains("Login")) {
			return true;	
		}
		else {
			System.out.println("false executed");
			return false;
		}
	}
	
	public void enterValidCredentials() {
		baseMethods.sendKey(inputTextBox_username, "your username");
		baseMethods.sendKey(inputTextBox_Password, "your password");
	}
	
	public void loginWithValidCredentials() {
		enterValidCredentials();
		baseMethods.clickOnButton(btn_Login, driver);
	}
	
	public boolean homePageOpen() {
		String welcomeText = Text_Welcome.getText();
		if (welcomeText.contains("Welcome")) {
			return true;
		} else {
			return false;
		}
	}
	
	
	
	
	
}