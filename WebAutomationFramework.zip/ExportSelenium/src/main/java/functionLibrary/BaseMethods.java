package functionLibrary;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class BaseMethods {

	JavascriptExecutor executor;
	
	public void sendKey(WebElement element, String inputValue) {
		element.sendKeys(inputValue);;
	}
	
	public void clickOnButton(WebElement element, WebDriver driver) {
		executor = (JavascriptExecutor)driver;
		executor.executeScript("arguments[0].click();", element);
	}
	
	
}
