package quickstart.Tests;

import java.io.IOException;
import java.lang.reflect.Method;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;
import functionLibrary.ReportLog;
import quickstart.Pages.LandingPage;

public class LandingPageTest {
	ReportLog logger;
	WebDriver driver;
	LandingPage landingpage;
	
	@BeforeSuite
	public void startTestSuite() {
		System.setProperty("webdriver.chrome.driver", "E:\\Harsh\\Automation\\chromedriver\\chromedriver.exe");
		driver = new ChromeDriver();
		logger= new ReportLog(driver);
	}
	
	@BeforeMethod
	public void startTest(Method m) {
		logger.startTest(m.getName());
		driver.get("your project URL");
		driver.manage().window().maximize();

	}
	
	@AfterMethod
	public void endTest() {
		logger.endTest();

	}

	@AfterSuite
	public void endTestSuite() {
		logger.endTestSuite();
		//driver.quit();
	}
	
	@Test
	public  void verifyLandingPage() throws IOException {
		landingpage = new LandingPage(driver);
		boolean PageTitle = landingpage.loginBtnVisible(); 
		if (PageTitle==true) {
			logger.logPass("Landing page of <project name> web portal gets open.");
			Assert.assertTrue(true);
		}
		else {
			logger.logFail("Landing page of <project name> web portal does not get open.");
			Assert.assertTrue(false);
		}
	}
	
	@Test
	public void verifyLoginwithValidCredentials() throws IOException {
		landingpage.loginWithValidCredentials();
		boolean checkHomePage = landingpage.homePageOpen();
		if(checkHomePage==true) {
			logger.logPass("Home page of <project name> web portal gets open.");
			Assert.assertTrue(true);
		} else {
			logger.logFail("Home page of <project name> web portal does not get open.");
			Assert.assertTrue(false);
		}
		
	}

}
